@echo off
chcp 65001 >nul
setlocal
set "YEAR=2024"
set "DEST=%APPDATA%\Autodesk\Revit\Addins\%YEAR%"
set "HERE=%~dp0"
set "EXE=%DEST%\BSP.Platform.Entry\bsp-launcher.exe"
set "CFG=%DEST%\BSP.Platform.Entry\config.json"
set "KEY=%~1"

echo.
echo   BSP 스토어 설치
echo   ---------------------------------------------
echo   놓는 곳 : %DEST%
echo.

if not exist "%HERE%BSP.Platform.Entry.addin" (
  echo   [멈춤] 설치 파일이 같은 폴더에 없습니다.
  echo          압축을 푼 뒤 그 안의 설치.bat 를 실행하세요.
  goto :fail
)

rem 리빗이 켜져 있으면 파일이 잠겨 복사가 실패한다 - 먼저 말한다.
tasklist /FI "IMAGENAME eq Revit.exe" 2>nul | find /I "Revit.exe" >nul
if not errorlevel 1 (
  echo   [멈춤] 리빗이 켜져 있습니다. 리빗을 닫고 다시 실행하세요.
  goto :fail
)

if not exist "%DEST%" mkdir "%DEST%" 2>nul
if not exist "%DEST%\BSP.Platform.Entry" mkdir "%DEST%\BSP.Platform.Entry" 2>nul

copy /y "%HERE%BSP.Platform.Entry.addin" "%DEST%\" >nul || goto :fail
copy /y "%HERE%BSP.Platform.Entry\BSP.Platform.Entry.dll"  "%DEST%\BSP.Platform.Entry\" >nul || goto :fail
copy /y "%HERE%BSP.Platform.Entry\BSP.Platform.Agent.dll"  "%DEST%\BSP.Platform.Entry\" >nul || goto :fail
copy /y "%HERE%BSP.Platform.Entry\bsp-launcher.exe"        "%DEST%\BSP.Platform.Entry\" >nul || goto :fail

rem 설정은 이미 있으면 덮지 않는다 - 그 PC 의 회사·주소를 지우면 안 된다.
if exist "%DEST%\BSP.Platform.Entry\config.json" (
  echo   설정 유지 ^(이미 있음^)
) else (
  copy /y "%HERE%BSP.Platform.Entry\config.json" "%DEST%\BSP.Platform.Entry\" >nul || goto :fail
)

rem HTS 가 꾸러미에 들어 있으면 같이 놓는다. 이미 있으면 덮지 않는다.
if exist "%HERE%HTS\BSP.Hub.addin" (
  if exist "%DEST%\BSP.Hub.addin" (
    echo   도구상자 유지 ^(이미 있음^)
  ) else (
    copy /y "%HERE%HTS\*" "%DEST%\" >nul
    echo   도구상자 함께 설치
  )
)
echo   파일 복사 끝

rem ── 열쇠 한 줄 ───────────────────────────────────────────────────
rem    설치본에는 열쇠를 **안 넣는다**. 넣으면 받은 사람 전부가 우리 열쇠를 갖는다.
rem    받는 분이 따로 받은 한 줄을 여기서 붙여넣으면, 심부름꾼이 처음 뜰 때
rem    **그 PC 것으로 잠근다**(평문으로 남지 않는다).
if "%KEY%"=="" (
  echo.
  echo   열쇠를 받으셨으면 붙여넣고 Enter 를 누르세요.
  echo   없으면 그냥 Enter - 설치는 끝나고, 목록만 나중에 보입니다.
  set /p "KEY=  열쇠 : "
)
if not "%KEY%"=="" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
   "$p='%CFG%'; $c=Get-Content $p -Raw | ConvertFrom-Json; $c.token='%KEY%'; [IO.File]::WriteAllText($p, ($c | ConvertTo-Json -Depth 8), (New-Object Text.UTF8Encoding $false))" >nul 2>&1
  if errorlevel 1 (echo   [주의] 열쇠를 넣지 못했습니다) else (echo   열쇠 넣음)
) else (
  echo   열쇠 없이 설치했습니다 - 목록을 보려면 나중에 열쇠를 넣어야 합니다
)

rem ── 로그온할 때 저절로 뜨게 (바로가기 하나) ──────────────────────
rem    이게 없으면 재부팅한 뒤 심부름꾼이 없다. 리빗을 켜도 아무것도 안 받는다.
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command ^
 "$s=(New-Object -ComObject WScript.Shell); $l=$s.CreateShortcut([IO.Path]::Combine($s.SpecialFolders('Startup'),'BSP 스토어.lnk')); $l.TargetPath='%EXE%'; $l.Arguments='watch-revit'; $l.WindowStyle=7; $l.Save()" >nul 2>&1
if errorlevel 1 (echo   [주의] 자동 시작 등록 실패 - 로그온할 때 저절로 뜨지 않습니다) else (echo   자동 시작 등록)

rem ── 지금 띄우기 - 창 없이 ────────────────────────────────────────
rem    start "" 로 콘솔 exe 를 그냥 띄우면 검은 창이 뜬다(실측).
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command ^
 "Start-Process -FilePath '%EXE%' -ArgumentList 'watch-revit' -WindowStyle Hidden" >nul 2>&1
if errorlevel 1 (
  echo   [주의] 심부름꾼을 띄우지 못했습니다
) else (
  echo   심부름꾼 시작
)

rem ── ★ 열쇠가 «정말» 잠겼는지 본다 ───────────────────────────────
rem    잠그는 일은 심부름꾼이 처음 뜰 때 한다. 안 떴으면 **열쇠가 평문으로 남는다.**
rem    「띄웠나」가 아니라 「잠겼나」를 봐야 한다 - 안 보고 말하면 비밀이 남은 채로 거짓말이 된다.
if not "%KEY%"=="" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
   "$p='%CFG%'; for($i=0;$i -lt 20;$i++){ try{ $c=Get-Content $p -Raw|ConvertFrom-Json; if(-not $c.token -and $c.tokenEnc){ exit 0 } }catch{}; Start-Sleep -Milliseconds 500 }; exit 1" >nul 2>&1
  if errorlevel 1 (
    rem ★ 못 잠갔으면 **지운다.** 정직하게 말하는 것만으로는 비밀이 디스크에 남는다.
    rem   열쇠는 다시 붙여넣을 수 있는 것이라, 남기는 쪽이 더 나쁘다.
    powershell -NoProfile -ExecutionPolicy Bypass -Command ^
     "$p='%CFG%'; $c=Get-Content $p -Raw|ConvertFrom-Json; $c.token=''; [IO.File]::WriteAllText($p,($c|ConvertTo-Json -Depth 8),(New-Object Text.UTF8Encoding $false)); $b=Get-Content $p -Raw|ConvertFrom-Json; if($b.token){exit 1}; exit 0" >nul 2>&1
    if errorlevel 1 (
      echo   [주의] 열쇠를 잠그지도, 지우지도 못했습니다.
      echo          %CFG% 를 열어 token 칸을 손으로 비워 주십시오.
    ) else (
      echo   [주의] 열쇠를 잠그지 못해 **지웠습니다** ^(확인함^).
      echo          리빗을 닫고 설치.bat 을 다시 실행해 열쇠를 넣어 주십시오.
    )
  ) else (
    echo   열쇠를 이 PC 것으로 잠갔습니다 ^(확인함^)
  )
)

echo.
echo   끝났습니다. 리빗을 켜면 리본에 [BSP] 탭이 생깁니다.
if "%KEY%"=="" echo   ^(열쇠를 안 넣으셨습니다 - 탭은 뜨지만 목록은 비어 있습니다^)
echo.
pause
exit /b 0

:fail
echo.
echo   설치하지 못했습니다.
echo.
pause
exit /b 1